#!/bin/bash
# A simple example of using a pipe to send the output of one command to another command
# Here, we list the files in the current directory and send the output to 'less'
# so that we can scroll through the list if it's long

ls -l | less