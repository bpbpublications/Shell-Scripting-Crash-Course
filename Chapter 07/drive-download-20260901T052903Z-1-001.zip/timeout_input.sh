#!/bin/bash

if read -t 5 -p "Enter your name (within 5 seconds): " username
then
    echo "Hello, $username"
else
    echo "⏰ Sorry, you didn’t enter anything in time."
fi
