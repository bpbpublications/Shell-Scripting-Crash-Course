#!/bin/bash

while read line
do
  echo "Line: $line"
done < names.txt
