#!/bin/bash

while getopts ":u:p:h" opt; do
  case $opt in
    u) username=$OPTARG ;;
    p) password=$OPTARG ;;
    h) 
       echo "Usage: $0 -u username -p password"
       exit 0
       ;;
    \?) 
       echo "❌ Invalid option: -$OPTARG"
       exit 1
       ;;
  esac
done

if [[ -n "$username" && -n "$password" ]]; then
  echo "Welcome $username! Your password is set."
else
  echo "Missing username or password. Use -h for help."
fi
