#!/bin/bash

src=$1
dest=$2

if [ -z "$src" ] || [ -z "$dest" ]; then
    echo "Usage: $0 source_directory destination_directory"
    exit 1
fi

echo "Backing up files from $src to $dest..."
cp -r "$src" "$dest"
echo "✅ Backup completed!"
