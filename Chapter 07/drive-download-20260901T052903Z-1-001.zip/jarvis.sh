#!/bin/bash

echo "==============================="
echo "     Welcome to Mini Jarvis     "
echo "==============================="

while true; do
  read -p "Ask me something (or type 'exit' to quit): " question
  
  # Exit condition
  if [[ "$question" == "exit" ]]; then
    echo "Jarvis: Goodbye, have a great day!"
    break
  fi

  # Simple responses
  case $question in
    "date")
      echo "Jarvis: Today is $(date)"
      ;;
    "time")
      echo "Jarvis: The current time is $(date +%T)"
      ;;
    "whoami")
      echo "Jarvis: You are $(whoami)"
      ;;
    "uptime")
      echo "Jarvis: System has been running for $(uptime -p)"
      ;;
    *)
      echo "Jarvis: Sorry, I don’t know how to answer that. Ask me about date, time, whoami, or uptime."
      ;;
  esac
done
