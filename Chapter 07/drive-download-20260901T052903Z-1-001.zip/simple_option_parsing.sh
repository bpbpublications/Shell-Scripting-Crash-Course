#!/bin/bash

while getopts ":a:b:" opt; do
  case $opt in
    a) echo "Option A with value: $OPTARG" ;;
    b) echo "Option B with value: $OPTARG" ;;
    \?) echo "Invalid option: -$OPTARG" ;;
  esac
done



