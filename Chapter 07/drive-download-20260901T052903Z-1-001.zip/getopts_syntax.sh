while getopts ":u:p:h" option; do
  case $option in
    u) user=$OPTARG ;;
    p) port=$OPTARG ;;
    h) echo "Usage: $0 -u username -p port"; exit 0 ;;
    \?) echo "Invalid option: -$OPTARG"; exit 1 ;;
  esac
done


