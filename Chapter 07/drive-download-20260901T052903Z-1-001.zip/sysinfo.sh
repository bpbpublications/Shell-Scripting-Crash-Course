#!/bin/bash

# Store values using command substitution
HOSTNAME=$(hostname)
USER=$(whoami)
TODAY=$(date)

# Print formatted output
echo "System Information:"
echo "Hostname: $HOSTNAME"
echo "User: $USER"
echo "Date: $TODAY"
