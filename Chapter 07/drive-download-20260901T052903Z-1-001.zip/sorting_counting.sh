#!/bin/bash

# This script counts the number of unique users on the system by processing the /etc/passwd file

cat /etc/passwd | cut -d: -f1 | sort | uniq | wc -l
