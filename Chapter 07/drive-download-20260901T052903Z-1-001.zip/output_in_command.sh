#!/bin/bash

files=$(ls *.sh)
echo "Shell scripts in this folder: $files"
