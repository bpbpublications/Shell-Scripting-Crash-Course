#!/bin/bash

while getopts ":u:p:" opt; do
  case $opt in
    u) username=$OPTARG ;;
    p) port=$OPTARG ;;
    \?) echo "Invalid option: -$OPTARG" ;;
  esac
done

# Shift away parsed options
# shift $((OPTIND -1))

echo "Username: $username"
echo "Port: $port"

# Remaining arguments
echo "Remaining args: $@"
echo "First remaining arg: $1"
