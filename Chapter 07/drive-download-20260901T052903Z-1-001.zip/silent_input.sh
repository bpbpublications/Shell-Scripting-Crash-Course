#!/bin/bash

read -s -p "Enter your password: " password
echo
echo "Password has been recorded securely."
echo "You entered a password with ${#password} characters, and Password is: $password"
