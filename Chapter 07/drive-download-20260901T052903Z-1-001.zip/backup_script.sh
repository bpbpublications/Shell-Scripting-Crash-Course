#!/bin/bash

src="/home/user/data"
dest="/mnt/backup"

echo "Starting backup..."
cp -r "$src" "$dest" > backup.log 2>&1

if [ $? -eq 0 ]; then
  echo "✅ Backup completed successfully!"
else
  echo "❌ Backup failed! Check backup.log"
fi
