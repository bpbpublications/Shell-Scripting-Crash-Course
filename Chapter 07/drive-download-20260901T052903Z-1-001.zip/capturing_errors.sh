#!/bin/bash

ls /no/such/path 2> error.log
