#!/bin/bash

PARSED=$(getopt --options u:p:h --long help,version -- "$@")
if [ $? -ne 0 ]; then
    echo "Error parsing options" >&2 # Redirect to stderr
    exit 1
else
    eval set -- "$PARSED"
    while true; do
        case "$1" in
            -u|--user) USERNAME="$2"; shift 2 ;;
            -p|--password) PASSWORD="$2"; shift 2 ;;
            -h|--help) echo "Usage: $0 -u username -p password"; exit 0 ;;
            --version) echo "Version 1.0"; exit 0 ;;
            --) shift; break ;;
            *) echo "Unknown option: $1" >&2; exit 1 ;;
        esac
    done
fi
