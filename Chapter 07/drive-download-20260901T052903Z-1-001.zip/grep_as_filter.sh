#!/bin/bash

# This script filters the output of the 'ps aux' command to show only processes related to 'bash'

ps aux | grep bash
