#!/bin/bash

echo "Current user is: $(whoami), and home directory is: $(eval echo ~$USER)"
