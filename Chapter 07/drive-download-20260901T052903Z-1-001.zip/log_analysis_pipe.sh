#!/bin/bash

# Count the number of 404 errors in the access log
# Note: access.log should be available while running this script

cat access.log | grep "404" | wc -l