#!/bin/bash

echo "Enter your first and last name:"
read first last
echo "First Name: $first"
echo "Last Name: $last"
