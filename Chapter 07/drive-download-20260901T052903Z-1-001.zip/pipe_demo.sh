#!/bin/bash

: << 'COMMENT' 
    1.	Lists all .sh files in the current directory.
    2.	Filters only those containing the word “config” in their name.
    3.	Counts how many such files exist.
COMMENT

# Count the number of .sh files containing "config" in their names
count=$(ls *.sh | grep "config" | wc -l)
echo "Number of config-related scripts: $count"