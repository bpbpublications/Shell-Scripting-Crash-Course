#!/bin/bash

ls -l > files.txt
