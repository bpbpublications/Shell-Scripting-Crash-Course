#!/bin/bash

read -p "Enter username: " username
read -s -p "Enter password: " password
echo
echo "Validating credentials for user: $username"
# Simulate validation (in real scenarios, validate against a database or file)

if [[ "$username" == "admin" && "$password" == "secret" ]]; then
    echo "Login successful!"
else
    echo "Login failed!"
fi  
