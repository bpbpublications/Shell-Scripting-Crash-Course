#!/bin/bash

ls -l > /dev/null
echo "Output discarded, nothing shown on screen."
