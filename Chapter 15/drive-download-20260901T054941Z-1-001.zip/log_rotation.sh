#!/bin/bash

logfile="/var/log/app.log"
archive="/var/log/app_$(date +%F).log"

mv "$logfile" "$archive"
touch "$logfile"