#!/bin/bash

# Create a temporary directory
TEMP_DIR=$(mktemp -d)

# Ensure the temporary directory is deleted on script exit
trap "rm -rf \"$TEMP_DIR\"" EXIT

# Generate a random filename
RANDOM_FILE=$(basename "$(mktemp -u)")

# Full file path
FILE_PATH="$TEMP_DIR/$RANDOM_FILE"

# Generate a random number between 1 and 100
RANDOM_NUMBER=$((RANDOM % 100 + 1))

# Generate a secure 32-character password
SECURE_PASSWORD=$(tr -dc 'A-Za-z0-9@#%&*' < /dev/urandom | head -c 32)

# Write data to the file
{
  echo "Random Number: $RANDOM_NUMBER"
  echo "Secure Password: $SECURE_PASSWORD"
} > "$FILE_PATH"

# Print directory and filename
echo "Temporary Directory: $TEMP_DIR"
echo "Filename: $RANDOM_FILE"
