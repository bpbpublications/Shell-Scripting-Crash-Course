#!/bin/bash

workdir=$(mktemp -d) # Create a safe temporary workspace
trap "rm -rf $workdir" EXIT # Ensure cleanup on exit

cp /var/log/syslog "$workdir/log_copy.txt" # Copy a log file to the workspace, copy from syslog to log_copy.txt
grep "error" "$workdir/log_copy.txt" > "$workdir/errors.txt" # Extract error lines

echo "Processed files in: $workdir" # Inform the user of the workspace location
