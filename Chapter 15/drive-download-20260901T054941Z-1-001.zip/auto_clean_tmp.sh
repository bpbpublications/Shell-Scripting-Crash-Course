#!/bin/bash
# This script creates a temporary file that is automatically deleted on exit

tmp=$(mktemp)
trap "rm -f $tmp" EXIT

echo "This file will be deleted automatically."