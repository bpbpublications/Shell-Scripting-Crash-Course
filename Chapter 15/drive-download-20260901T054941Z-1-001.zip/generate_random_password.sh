#!/bin/bash
# This script generates a random 12-character alphanumeric password

password=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 12)
echo "Password: $password"
