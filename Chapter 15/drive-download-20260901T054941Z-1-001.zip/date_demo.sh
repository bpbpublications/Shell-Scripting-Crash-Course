#!/bin/bash

# Print the current date and time
echo "Current date and time:"
date

echo

# Print yesterday's date
echo "Yesterday's date:"
date -d "yesterday"

echo

# Print the date 30 days from now
echo "Date 30 days from now:"
date -d "+30 days"

echo

# Create a file named report_<DATE>.txt using today's date
TODAY=$(date +"%Y-%m-%d")
FILENAME="report_${TODAY}.txt"
touch "$FILENAME"
echo "Created file: $FILENAME"

echo

# Bonus: Compare today's date with a fixed future date
FUTURE_DATE="2025-12-31"

TODAY_SECONDS=$(date -d "$TODAY" +%s)
FUTURE_SECONDS=$(date -d "$FUTURE_DATE" +%s)

if [ "$TODAY_SECONDS" -gt "$FUTURE_SECONDS" ]; then
    echo "The date $FUTURE_DATE has already passed."
else
    echo "The date $FUTURE_DATE has not passed yet."
fi
