#!/bin/bash

date1=$(date -d "2025-01-01" +%s)
date2=$(date +%s)

if [ "$date2" -gt "$date1" ]; then
  echo "Current date is after 2025-01-01"
fi