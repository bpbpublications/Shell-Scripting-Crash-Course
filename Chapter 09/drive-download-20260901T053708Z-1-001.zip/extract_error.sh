grep "ERROR" app.log | cut -d' ' -f1-3
