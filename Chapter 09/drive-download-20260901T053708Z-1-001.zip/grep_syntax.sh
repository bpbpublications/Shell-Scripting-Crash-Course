grep [options] pattern [file...]
