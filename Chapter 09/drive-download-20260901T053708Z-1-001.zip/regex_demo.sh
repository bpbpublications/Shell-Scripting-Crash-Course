#!/bin/bash

# regex_demo.sh

DATAFILE="data.txt"

# 1) Find all lines that start with "user"
grep '^user' "$DATAFILE"

# 2) Find all lines ending with /bin/bash
grep '/bin/bash$' "$DATAFILE"

# 3) Extract the email address (prints only the matching part)
grep -Eo '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}' "$DATAFILE"

# 4) Extract the IP address (prints only the matching part)
grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' "$DATAFILE"
