#!/bin/bash

# sed_demo.sh
# Replaces 'Linux' with 'Unix', deletes line containing 'Debug', and masks the password.

sed -i -e 's/Linux/Unix/' -e '/Debug/d' -e 's/^Password=.*/Password=*****/' notes.txt
