#!/bin/bash

# File: extract_demo.sh

# 1. Print only the names of students (skipping the header)
awk -F, 'NR>1 {print $2}' students.csv

echo ""

# 2. Print names and marks of students with marks > 80
awk -F, 'NR>1 && $3 > 80 {print $2, $3}' students.csv

echo ""

# 3. Print the total number of students (excluding header)
awk -F, 'NR>1 {count++} END {print "Total students:", count}' students.csv # END used to execute after processing all lines
