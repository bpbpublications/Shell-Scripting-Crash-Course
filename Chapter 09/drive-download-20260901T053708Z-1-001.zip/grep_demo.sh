#!/bin/bash

# Print lines containing "Error" (case-insensitive)
grep -i "Error" sample.txt

# Count total matches
count=$(grep -ic "Error" sample.txt)
echo "Total matches: $count"
