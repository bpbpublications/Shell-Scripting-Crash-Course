#!/bin/bash

TMP_DIR="/tmp/demo_temp"

cleanup_sigint() {
  echo "Caught interruption! Cleaning up..."
  rm -rf "$TMP_DIR"
  exit 1
}

on_exit() {
  echo "Script finished execution."
}

trap cleanup_sigint SIGINT
trap on_exit EXIT

mkdir -p "$TMP_DIR"

# simulate long work
while true; do
  sleep 2
done
