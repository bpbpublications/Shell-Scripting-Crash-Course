#!/bin/bash

WORKDIR=$(mktemp -d)

trap 'rm -rf "$WORKDIR"; echo "Removed $WORKDIR"; exit' EXIT

echo "Working directory: $WORKDIR"
# Simulate processing
sleep 3
echo "Processing complete."
