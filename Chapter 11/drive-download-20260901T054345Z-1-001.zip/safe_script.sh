#!/bin/bash
set -euo pipefail

# Define a valid source directory
src_dir="/tmp"

# Intentionally use an unset variable to test `set -u`
echo "Destination directory: $dest_dir"

# Intentionally failing command to test `set -e`
cp /no/file /tmp

# This line should never run
echo "This should not appear!"
