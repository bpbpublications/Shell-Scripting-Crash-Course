#!/bin/bash

echo "Starting process..."

# Enable debug mode
set -x

# Create directory and copy file
mkdir -p /tmp/debug_demo
cp /etc/passwd /tmp/debug_demo/

# Example of a failing command (uncomment to test)
# cp /no/file /tmp

# Disable debug mode
set +x

echo "Process completed."
