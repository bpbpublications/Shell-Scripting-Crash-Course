#!/bin/bash
set -euo pipefail

backup_dir="/backup"
mkdir -p "$backup_dir"

tar -czf "$backup_dir/data.tar.gz" /home/user/data
echo "Backup completed successfully!"
