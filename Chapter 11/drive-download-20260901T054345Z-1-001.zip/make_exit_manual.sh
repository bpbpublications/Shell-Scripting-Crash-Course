ls /etc/passwd
echo "Exit code: $?"

ls /nonexistent/file
echo "Exit code: $?"