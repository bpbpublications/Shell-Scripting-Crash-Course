#!/bin/bash
echo "Starting script..."
cp /nonexistent/file /tmp/
echo "This line still runs!"
