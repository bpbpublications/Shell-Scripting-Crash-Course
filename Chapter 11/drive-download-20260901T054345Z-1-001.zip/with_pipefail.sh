#!/bin/bash
set -o pipefail
cat missingfile.txt | grep "root" | wc -l
echo "This line won’t run if any command fails."
