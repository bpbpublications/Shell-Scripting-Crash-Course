#!/bin/bash
set -e
echo "Starting script..."
cp /nonexistent/file /tmp/
echo "This line will not run!"
