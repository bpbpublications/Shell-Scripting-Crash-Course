#!/bin/bash
cat missingfile.txt | grep "root" | wc -l
echo "Completed"
