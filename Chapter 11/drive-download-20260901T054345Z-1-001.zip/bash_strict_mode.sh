#!/bin/bash
set -euo pipefail

input_file="/etc/passwd"
output_file="/tmp/usernames.txt"

grep "bash" "$input_file" | cut -d: -f1 > "$output_file"

echo "Usernames saved to $output_file"
