#!/bin/bash
file="/etc/passwd"

if [ -f "$file" ]; then
  echo "File found."
  exit 0
else
  echo "File not found!"
  exit 1
fi
