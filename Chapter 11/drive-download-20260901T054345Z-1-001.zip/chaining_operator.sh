mkdir /tmp/test_dir && echo "Directory created successfully"
rm /not_exist && echo "Removed" || echo "Removal failed"
