#!/bin/bash

# Run any command
CMD="ls /tmp"   # Change this line to test different commands
echo "Command: $CMD"

# Execute the command
$CMD
STATUS=$?

# Check exit status
if [ $STATUS -eq 0 ]; then
  echo "Command successful"
else
  echo "Command failed"
fi

# Print the exit code
echo "Exit code: $STATUS"

# End with a custom exit code (optional)
exit $STATUS
