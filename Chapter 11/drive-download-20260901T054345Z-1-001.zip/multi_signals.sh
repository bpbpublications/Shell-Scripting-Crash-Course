trap 'echo "Terminated! Performing cleanup..."; rm -f /tmp/myapp.lock' SIGINT SIGTERM
