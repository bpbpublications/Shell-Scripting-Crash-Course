#!/bin/bash
file="/etc/passwd"

echo "[DEBUG] Checking if $file exists..."
if [ -f "$file" ]; then
  echo "[INFO] File found!"
else
  echo "[ERROR] File not found!"
fi
