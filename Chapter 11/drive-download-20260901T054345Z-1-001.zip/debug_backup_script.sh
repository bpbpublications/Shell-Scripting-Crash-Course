#!/bin/bash
set -x  # Enable debug

src="/home/user/data"
dest="/mnt/backup"

echo "Starting backup..."
cp -r "$src" "$dest" || echo "[ERROR] Copy failed!"

set +x  # Disable debug
echo "Backup script completed."
