#!/bin/bash

set -x
name="Alice"
echo "Hello, $name!"
mkdir /tmp/test_folder
set +x
echo "Done."
