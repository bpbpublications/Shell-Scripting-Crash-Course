#!/bin/bash
echo "Starting script..."

set -x
cp /etc/passwd /tmp/
grep root /tmp/passwd
set +x

echo "Script finished."
