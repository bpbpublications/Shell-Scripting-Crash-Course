#!/bin/bash
set -u
name="John"
echo "Hello, $username"
echo "Script completed."
