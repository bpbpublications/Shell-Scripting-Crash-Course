#!/bin/bash

trap 'echo "You pressed Ctrl + C. Exiting safely..."; exit 1' SIGINT
echo "Running... Press Ctrl + C to stop."
while true; do
  sleep 1
done