#!/bin/bash
name="John"
echo "Hello, $username"
echo "Script completed."
