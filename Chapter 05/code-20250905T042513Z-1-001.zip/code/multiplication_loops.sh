#!/bin/bash

##########################################
# Script: multiplication_loops.sh
# Purpose: Practice for, while, and until loops
# Author: John Doe
##########################################

echo "=== For Loop: Table of 2 ==="
for num in {1..10}
do
    echo "2 x $num = $((2 * num))"
done

echo
echo "=== While Loop: Table of 3 ==="
count=1
while [ $count -le 10 ]
do
    echo "3 x $count = $((3 * count))"
    ((count++))
done

echo
echo "=== Until Loop: Table of 4 ==="
n=1
until [ $n -gt 10 ]
do
    echo "4 x $n = $((4 * n))"
    ((n++))
done
