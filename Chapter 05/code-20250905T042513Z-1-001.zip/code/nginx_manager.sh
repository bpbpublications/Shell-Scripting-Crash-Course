#!/bin/bash

# Script: nginx_manager.sh
# Purpose: Manage Nginx service using case statements
# Author: John Doe
# Date: 2025-08-17

echo "Enter an action: start | stop | restart | status"
read action

case $action in
    start)
        echo "🔵 Starting Nginx..."
        sudo systemctl start nginx
        ;;
    stop)
        echo "🔴 Stopping Nginx..."
        sudo systemctl stop nginx
        ;;
    restart)
        echo "🟠 Restarting Nginx..."
        sudo systemctl restart nginx
        ;;
    status)
        echo "🟢 Checking Nginx status..."
        sudo systemctl status nginx
        ;;
    *)
        echo "❌ Invalid option. Use start | stop | restart | status"
        ;;
esac

