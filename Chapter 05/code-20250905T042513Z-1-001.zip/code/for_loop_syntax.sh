for variable in list
do
    commands
done
