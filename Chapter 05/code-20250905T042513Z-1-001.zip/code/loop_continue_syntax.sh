#!/bin/bash

for num in {1..5}
do
    if [ $num -eq 3 ]; then
        echo "Found 3, breaking the loop!"
        break
    fi
    echo "Number: $num"
done
