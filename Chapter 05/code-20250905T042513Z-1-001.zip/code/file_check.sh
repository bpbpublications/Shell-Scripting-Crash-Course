#!/bin/bash

echo "Enter a file or directory path:"
read path

if [ -f "$path" ]
then
    echo "It’s a regular file."
elif [ -d "$path" ]
then
    echo "It’s a directory."
else
    echo "The path does not exist."
fi
