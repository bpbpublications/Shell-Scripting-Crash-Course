#!/bin/bash

##########################################
# Script: loop_control.sh
# Purpose: Practice break and continue
# Author: John Doe
##########################################

echo "=== Using break (stop at 5) ==="
for i in {1..10}
do
    if [ $i -eq 5 ]; then
        echo "Reached 5, stopping loop!"
        break
    fi
    echo "Value: $i"
done

echo
echo "=== Using continue (skip even numbers) ==="
for i in {1..10}
do
    if [ $((i % 2)) -eq 0 ]; then
        continue
    fi
    echo "Odd number: $i"
done
