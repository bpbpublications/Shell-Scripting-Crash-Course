if [ condition ]
then
    # Commands to run if condition is true
elif [ another_condition ]
then
    # Commands to run if another condition is true
else
    # Commands to run if all conditions are false
fi
