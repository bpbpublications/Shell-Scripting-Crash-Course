#!/bin/bash

# Script: day_message.sh
# Purpose: Print message based on day of the week

echo "Enter a day (mon, tue, wed, thu, fri, sat, sun):"
read day

case $day in
    mon)
        echo "📂 Start of the work week!"
        ;;
    fri)
        echo "🎉 Almost weekend!"
        ;;
    sat|sun)
        echo "😎 It's the weekend!"
        ;;
    tue|wed|thu)
        echo "📘 It's a weekday, keep working hard!"
        ;;
    *)
        echo "❓ Invalid day entered."
        ;;
esac
