for variable in list
do
    if [ condition ]; then
        break
    fi
done
