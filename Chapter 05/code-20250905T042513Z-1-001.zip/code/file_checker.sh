#!/bin/bash

# Script: file_checker.sh
# Purpose: Identify file type by extension

echo "Enter a filename:"
read filename

case $filename in
    *.txt)
        echo "📄 It's a text file."
        ;;
    *.sh)
        echo "📜 It's a shell script."
        ;;
    *.log)
        echo "📝 It's a log file."
        ;;
    *.tar.gz|*.zip)
        echo "📦 It's a compressed archive."
        ;;
    *)
        echo "❓ Unknown file type."
        ;;
esac
