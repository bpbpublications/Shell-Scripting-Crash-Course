#!/bin/bash

set -euo pipefail

grep "ERROR" *.log | sort | uniq -c | sort -nr