#!/bin/sh

if [ -f "/etc/os-release" ]; then
    echo "Linux system detected"
else
    echo "Unknown system"
fi