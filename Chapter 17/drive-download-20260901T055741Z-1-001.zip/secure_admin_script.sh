#!/bin/bash
set -euo pipefail

read -r action

case "$action" in
    start|stop)
        systemctl "$action" myservice # Replace 'myservice' with the actual service name
        ;;
    *)
        echo "Invalid action"
        exit 1
        ;;
esac
