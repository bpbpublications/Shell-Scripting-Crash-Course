#!/bin/bash

LOG_FILE="/tmp/app.log"

log_message() {
    echo "$(date): $1" >> "$LOG_FILE"
}

log_message "Application started"
