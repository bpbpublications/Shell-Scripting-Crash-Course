#!/bin/bash

# Script Name: deploy_release.sh
# Description: Simulates deployment of an application release
# Author: Operations Team
# Note: Maintained by multiple team members

# Exit immediately if any command fails
# Prevents partial or inconsistent deployments
set -e

# Security check: ensure script is not run as root
# Running as root could cause accidental system-wide changes
if [ "$EUID" -eq 0 ]; then
    echo "Do not run this script as root."
    exit 1
fi

# Application version to deploy
APP_VERSION="v1.2.0"  # Update only after approval

# Simulated deployment step
echo "Deploying application version $APP_VERSION"

# Temporary rollback command (disabled during normal operation)
# rollback_app.sh