#!/bin/bash

Xdialog --yesno "Apply changes now?" 10 50

if [ $? -eq 0 ]; then
  echo "Changes will be applied."
else
  echo "Operation cancelled."
fi