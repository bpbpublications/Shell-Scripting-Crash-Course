#!/bin/bash

dialog --yesno "Continue?" 8 40

if [ $? -eq 0 ]; then
  echo "User chose Yes"
else
  echo "User chose No"
fi