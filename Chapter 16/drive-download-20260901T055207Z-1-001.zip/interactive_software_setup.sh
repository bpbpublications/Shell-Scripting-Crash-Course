#!/bin/bash

dialog --msgbox "Welcome to MyApp Installer" 10 40

dialog --yesno "Do you want to install MyApp?" 10 40
if [ $? -ne 0 ]; then
  dialog --msgbox "Installation cancelled." 8 40
  clear
  exit 1
fi

name=$(dialog --inputbox "Enter admin username:" 10 40 \
  3>&1 1>&2 2>&3)

dialog --msgbox "Installing for user: $name" 10 40
clear
