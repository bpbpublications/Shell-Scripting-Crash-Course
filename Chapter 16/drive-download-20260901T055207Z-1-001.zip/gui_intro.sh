#!/bin/bash

# Script: gui_intro.sh
# Purpose: Demonstrate basic GUI interaction using dialog

# Temporary file for dialog output
TMP_FILE=$(mktemp)

# Display welcome message
dialog --title "Welcome" \
       --msgbox "Welcome to the GUI-based Shell Script Demo!" 8 45

# Ask if the user wants to continue
dialog --title "Confirmation" \
       --yesno "Do you want to continue?" 8 40

# Capture exit status of yes/no dialog
RESPONSE=$?

# If user selects Yes (exit status 0)
if [ $RESPONSE -eq 0 ]; then
    # Ask for user's name
    dialog --title "User Input" \
           --inputbox "Please enter your name:" 8 40 2> "$TMP_FILE"

    NAME=$(cat "$TMP_FILE")

    # Display greeting message
    dialog --title "Greeting" \
           --msgbox "Hello, $NAME! 👋\nWelcome to GUI Shell Scripting." 8 50
else
    # If user selects No
    dialog --title "Exit" \
           --msgbox "You chose not to continue. Exiting script." 8 45
fi

# Cleanup
rm -f "$TMP_FILE"
clear
