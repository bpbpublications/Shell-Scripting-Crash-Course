#!/bin/bash

# Exit immediately if dialog is not installed
command -v dialog >/dev/null 2>&1 || {
  echo "dialog is not installed. Install it with: sudo apt install dialog"
  exit 1
}

while true; do
  # Welcome menu
  choice=$(dialog --clear \
    --title "Welcome" \
    --menu "Choose an option:" 15 50 3 \
    Start "Start the process" \
    Settings "Configure settings" \
    Exit "Quit the program" \
    3>&1 1>&2 2>&3)

  status=$?

  # Handle Cancel / ESC
  if [ $status -ne 0 ]; then
    break
  fi

  case "$choice" in
    Start)
      # Progress gauge
      (
        for i in 0 20 40 60 80 100; do
          echo $i
          sleep 1
        done
      ) | dialog --gauge "Starting process..." 10 50 0
      ;;

    Settings)
      # Input box
      setting=$(dialog --inputbox "Enter a setting value:" 10 50 \
        3>&1 1>&2 2>&3)

      if [ $? -eq 0 ]; then
        dialog --msgbox "You entered: $setting" 8 40
      fi
      ;;

    Exit)
      break
      ;;
  esac
done

# Cleanup and exit
clear
echo "Goodbye!"