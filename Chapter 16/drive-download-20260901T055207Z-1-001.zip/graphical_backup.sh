#!/bin/bash

source_dir=$(yad --file --directory --title="Select Source Directory")
dest_dir=$(yad --file --directory --title="Select Backup Destination")

yad --info --text="Backing up from $source_dir to $dest_dir"