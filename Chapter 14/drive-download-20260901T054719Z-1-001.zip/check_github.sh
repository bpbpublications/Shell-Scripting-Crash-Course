#!/bin/bash

url="https://github.com"
status=$(curl -o /dev/null -s -w "%{http_code}" "$url")

if [ "$status" -eq 200 ]; then
    echo "GitHub is reachable (HTTP 200)."
else
    echo "GitHub is NOT reachable! Status code: $status"
fi
