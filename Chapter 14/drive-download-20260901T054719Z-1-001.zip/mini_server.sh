#!/bin/bash

FILE="hello.html"
PORT=9000

while true; do
{
    echo "HTTP/1.1 200 OK"
    echo "Content-Type: text/html; charset=UTF-8"
    echo "Connection: close"
    echo
    cat "$FILE"
} | nc -l "$PORT"
done