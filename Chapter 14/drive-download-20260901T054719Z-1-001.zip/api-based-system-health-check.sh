#!/bin/bash

response=$(curl -s -o /dev/null -w "%{http_code}" https://www.google.com)

if [ "$response" -eq 200 ]; then
    echo "API is healthy."
else
    echo "Warning: API is down! HTTP Status: $response"
fi