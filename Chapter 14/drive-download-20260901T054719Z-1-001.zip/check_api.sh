#!/bin/bash

URL="https://jsonplaceholder.typicode.com/users"

STATUS=$(curl -o /dev/null -s -w "%{http_code}" "$URL")

if [ "$STATUS" -eq 200 ]; then
    echo "API healthy"
else
    echo "API NOT healthy (status: $STATUS)"
fi
