#!/bin/bash

response=$(curl -s \
  'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd')

rate=$(echo "$response" | jq '.bitcoin.usd')

echo "Current Bitcoin price (USD): $rate"