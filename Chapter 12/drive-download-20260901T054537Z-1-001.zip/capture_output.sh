#!/bin/bash

# Capture username
USER_NAME=$(whoami)

# Capture uptime
UPTIME_INFO=$(uptime -p)

# Capture disk usage of root filesystem
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}')

# Formatted summary
echo "User: $USER_NAME"
echo "Uptime: $UPTIME_INFO"
echo "Disk Usage: $DISK_USAGE"

# Save output to file
{
    echo "User: $USER_NAME"
    echo "Uptime: $UPTIME_INFO"
    echo "Disk Usage: $DISK_USAGE"
} > /tmp/system_summary.txt
