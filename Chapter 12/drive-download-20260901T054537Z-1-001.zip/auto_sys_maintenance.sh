#!/bin/bash

echo "===== Daily System Maintenance ====="
echo "Date: $(date)"
echo "1. Cleaning /tmp directory..."
rm -rf /tmp/*
echo "2. Checking available disk space..."
df -h | grep '^/dev/'
echo "3. Checking active users..."
who
echo "4. Monitoring top 3 memory-consuming processes..."
ps -eo pid,comm,%mem --sort=-%mem | head -4
echo "===================================="
