#!/bin/bash
echo "Checking network connectivity..."
ping -c 2 google.com

echo "Fetching IP information:"
hostname -I

echo "Testing web access:"
curl -s https://example.com | head -5
