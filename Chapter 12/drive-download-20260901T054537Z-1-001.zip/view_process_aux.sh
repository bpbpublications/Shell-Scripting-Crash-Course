#!/bin/bash
echo "Showing all running processes (ps aux):"
ps aux | head -10
