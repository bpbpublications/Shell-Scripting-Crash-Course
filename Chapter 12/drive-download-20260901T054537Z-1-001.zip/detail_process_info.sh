#!/bin/bash
ps -eo pid,comm,user,%mem,%cpu --sort=-%mem | head -5
