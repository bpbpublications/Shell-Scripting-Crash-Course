#!/bin/bash

# sys_manage.sh - System Management Report Script

# Save output file
OUTPUT="/tmp/system_report.txt"

# Start writing report
{
    echo "===== System Management Report ====="
    echo "Generated on: $(date)"
    echo "User: $(whoami)"
    echo "System Uptime:"
    uptime
    echo

    echo "===== Active Users ====="
    who
    echo

    echo "===== Disk Usage (df -h) ====="
    df -h
    echo

    echo "===== Top 5 Memory-Consuming Processes ====="
    ps aux --sort=-%mem | head -n 6
    echo

    echo "===== Network Connectivity Test (ping google.com) ====="
    ping -c 4 google.com
    echo

    echo "===== End of Report ====="
} > "$OUTPUT"

# Display message
echo "System report saved to $OUTPUT"