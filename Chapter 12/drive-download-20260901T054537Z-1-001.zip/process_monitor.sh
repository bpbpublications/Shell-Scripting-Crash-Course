#!/bin/bash

echo "=== Top 5 Memory-Consuming Processes ==="
ps aux --sort=-%mem | head -n 6
echo ""

echo "=== Checking sshd Process ==="
pid=$(pgrep sshd)

if [ -z "$pid" ]; then
    echo "sshd is not running"
    echo "Attempting to start sshd..."
    systemctl start sshd
else
    echo "sshd is active with PID $pid"
fi
