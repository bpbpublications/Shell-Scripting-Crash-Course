#!/bin/bash

echo "Running processes:"
ps -e | head -5

echo "Killing a process example:"
# kill <PID>   # Uncomment and provide a PID to terminate a process

echo "System services:"
systemctl list-units --type=service --state=running | head -5