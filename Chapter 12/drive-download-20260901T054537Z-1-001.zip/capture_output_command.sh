#!/bin/bash

current_user=$(whoami)
current_date=$(date)

echo "User: $current_user"
echo "Date: $current_date"
