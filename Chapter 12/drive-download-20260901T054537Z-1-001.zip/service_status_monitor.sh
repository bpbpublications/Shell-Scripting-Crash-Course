#!/bin/bash
service_name="sshd"
status=$(systemctl is-active $service_name)

if [ "$status" == "active" ]; then
  echo "$service_name is running ✅"
else
  echo "$service_name is not running ❌"
fi
