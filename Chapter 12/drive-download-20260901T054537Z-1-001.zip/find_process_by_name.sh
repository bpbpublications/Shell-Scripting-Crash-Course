#!/bin/bash
pid=$(pgrep sshd)

if [ -n "$pid" ]; then
  echo "sshd is running with PID: $pid"
else
  echo "sshd process not found!"
fi
