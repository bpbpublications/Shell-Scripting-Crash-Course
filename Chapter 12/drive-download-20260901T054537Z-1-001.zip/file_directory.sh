#!/bin/bash

echo "Creating a backup directory..."
mkdir -p /tmp/backup

echo "Copying files..."
cp /etc/passwd /tmp/backup/

echo "Listing contents:"
ls -l /tmp/backup