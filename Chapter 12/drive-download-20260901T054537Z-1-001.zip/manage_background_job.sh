#!/bin/bash
echo "Starting a background process..."
sleep 60 &
echo "Background process started with PID: $!"
jobs
