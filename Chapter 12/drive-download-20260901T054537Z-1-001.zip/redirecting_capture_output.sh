#!/bin/bash
report=$(uptime)
echo "System Uptime: $report" > /tmp/system_status.txt
