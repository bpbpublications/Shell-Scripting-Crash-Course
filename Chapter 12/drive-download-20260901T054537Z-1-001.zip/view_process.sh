#!/bin/bash
echo "All running processes:"
ps -e | head -10
