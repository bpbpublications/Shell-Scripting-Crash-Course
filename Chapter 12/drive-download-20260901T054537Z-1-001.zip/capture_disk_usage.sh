#!/bin/bash

disk_usage=$(df -h / | awk 'NR==2 {print $5}')

echo "Root partition usage: $disk_usage"
