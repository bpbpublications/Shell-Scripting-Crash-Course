#!/bin/bash
pid=$(pgrep firefox)

if [ -n "$pid" ]; then
  echo "Killing Firefox (PID: $pid)"
  kill "$pid"
else
  echo "Firefox is not running."
fi
