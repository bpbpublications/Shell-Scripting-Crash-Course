#!/bin/bash
process_name="sshd"
pid=$(pgrep "$process_name")

if [ -z "$pid" ]; then
  echo "[$(date)] $process_name is NOT running! Restarting..."
  systemctl start "$process_name"
else
  echo "[$(date)] $process_name is running with PID $pid"
fi
