#!/bin/bash

echo "===== System Information ====="
uname -a
echo "Uptime:"
uptime
echo "Disk Usage:"
df -h
echo "Memory Usage:"
free -h