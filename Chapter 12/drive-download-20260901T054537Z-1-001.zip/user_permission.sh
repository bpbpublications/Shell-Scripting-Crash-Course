#!/bin/bash

echo "Current user: $(whoami)"
echo "User ID and Groups:"
id
echo "Home directory: $HOME"
