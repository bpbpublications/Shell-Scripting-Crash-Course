#!/bin/bash
echo "Current directory has $(ls | wc -l) files."
