#!/bin/bash

mem_used=$(free -m | awk '/Mem:/ {print $3}')
mem_total=$(free -m | awk '/Mem:/ {print $2}')

usage_percent=$((mem_used * 100 / mem_total))

if [ $usage_percent -gt 80 ]; then
  echo "Warning: Memory usage high ($usage_percent%)"
else
  echo "Memory usage normal ($usage_percent%)"
fi
