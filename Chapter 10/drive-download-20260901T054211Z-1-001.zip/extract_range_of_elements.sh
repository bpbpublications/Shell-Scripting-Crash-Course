#!/bin/bash

numbers=(10 20 30 40 50)
echo ${numbers[@]:1:3}