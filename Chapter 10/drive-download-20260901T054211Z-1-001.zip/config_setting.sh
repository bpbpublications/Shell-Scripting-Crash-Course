#!/bin/bash

declare -A config=(
    [username]="admin"
    [password]="secret123"
    [host]="localhost"
    [port]=3306
)

echo "Connecting to ${config[host]} as ${config[username]}..."