#!/bin/bash

folders=("docs" "images" "projects")
backup_path="backup"

mkdir -p "$backup_path"

for dir in "${folders[@]}"
do
  echo "Backing up $dir..."
  cp -r "$dir" "$backup_path/"
done

echo "Backup completed!"