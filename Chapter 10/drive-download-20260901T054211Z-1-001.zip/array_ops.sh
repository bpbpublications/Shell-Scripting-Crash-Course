#!/bin/bash

# Script: array_ops.sh
# Description: Performs operations on arrays (city names)

# Step 1: Declare an array of 5 cities
cities=("Delhi" "Mumbai" "Pune" "Chennai" "Kolkata")

# Step 2: Loop through the array and print each city
for city in "${cities[@]}"; do
    echo "City: $city"
done

# Step 3: Copy the array to another variable
copied_cities=("${cities[@]}")

# Step 4: Combine it with another array of 2 extra cities
extra_cities=("Hyderabad" "Bengaluru")
combined_cities=("${copied_cities[@]}" "${extra_cities[@]}")

# Step 5: Print the total number of cities
echo "Total cities: ${#combined_cities[@]}"

# Step 6: Display a slice of the array (2nd to 4th element)
slice=("${cities[@]:1:3}")  # from index 1, take 3 elements
echo "Selected slice: ${slice[@]}"
