declare -A student=(
    [name]="Alice"
    [age]=25
    [city]="Delhi"
)
