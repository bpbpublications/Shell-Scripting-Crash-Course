#!/bin/bash

fruits=("apple" "mango" "orange")

for i in "${!fruits[@]}"
do
  echo "Index $i: ${fruits[$i]}"
done