#!/bin/bash

fruits=("apple" "mango" "orange")

veggies=("carrot" "broccoli")

food=("${fruits[@]}" "${veggies[@]}")

echo "All food items: ${food[@]}"