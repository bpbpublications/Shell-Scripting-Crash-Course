files=("report.txt" "data.csv" "logfile.log")

echo "The first file is: ${files[0]}"
echo "All files: ${files[@]}"
echo "Number of files: ${#files[@]}"
