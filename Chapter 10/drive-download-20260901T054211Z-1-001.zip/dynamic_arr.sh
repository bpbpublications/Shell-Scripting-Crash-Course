#!/bin/bash

names=("Alice" "Bob")
names+=("Charlie" "David")

echo "Names: ${names[@]}"