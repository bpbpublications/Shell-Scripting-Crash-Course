#!/bin/bash

files=( $(ls *.txt) ) # Stores names of .txt files in an array

echo "Text files found: ${files[@]}"