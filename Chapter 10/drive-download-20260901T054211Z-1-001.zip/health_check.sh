#!/bin/bash

# health_check.sh

# Array of server hostnames/IPs
servers=("google.com" "facebook.com" "x.com" "nonexistent.domain")

echo "Starting server health check..."

for srv in "${servers[@]}"
do
    echo "Checking connection to $srv..."
    ping -c 1 "$srv" &> /dev/null

    if [ $? -eq 0 ]; then
        echo "$srv is reachable ✅"
    else
        echo "$srv is unreachable ❌"
    fi
    echo "----------------------"
done

echo "Health check completed."