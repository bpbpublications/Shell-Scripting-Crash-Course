#!/bin/bash

# Declare an associative array
declare -A employee=(
    [name]="Alice"
    [id]="E101"
    [role]="Developer"
    [department]="IT"
)

# Print all key-value pairs
for key in "${!employee[@]}"; do
    echo "$key: ${employee[$key]}"
done

# Remove one key (role)
unset 'employee[role]'

echo "After removing role:"

# Print remaining key-value pairs
for key in "${!employee[@]}"; do
    echo "$key: ${employee[$key]}"
done