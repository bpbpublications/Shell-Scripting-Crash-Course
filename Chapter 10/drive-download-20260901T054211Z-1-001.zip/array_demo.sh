#!/bin/bash

# array_demo.sh - Demonstrates basic array operations in bash

# 1. Declare an array of 5 colors
colors=("red" "green" "blue" "yellow" "purple")

echo "Original colors: ${colors[@]}"

# 2. Print the first and last color
echo "First color: ${colors[0]}"
echo "Last color: ${colors[-1]}"   # Bash 4.3+ supports negative indices
# If your shell doesn’t support negative indices, use:
# echo "Last color: ${colors[${#colors[@]}-1]}"

# 3. Print the total number of colors
echo "Total number of colors: ${#colors[@]}"

# 4. Update one color (replace 'blue' with 'cyan')
colors[2]="cyan"
echo "Updated colors (blue -> cyan): ${colors[@]}"

# 5. Remove one color (remove 'yellow')
unset colors[3]
echo "After removing yellow: ${colors[@]}"

# 6. Print the final list of colors
echo "Final list of colors: ${colors[@]}"
