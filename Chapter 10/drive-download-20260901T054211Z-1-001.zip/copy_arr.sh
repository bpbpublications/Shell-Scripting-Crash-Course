#!/bin/bash

fruits=("apple" "mango" "orange")

new_fruits=("${fruits[@]}")
echo "New array: ${new_fruits[@]}"