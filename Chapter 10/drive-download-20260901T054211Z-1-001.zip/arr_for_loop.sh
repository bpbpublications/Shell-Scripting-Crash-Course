#!/bin/bash

fruits=("apple" "mango" "orange")

for item in "${fruits[@]}"
do
  echo "Fruit: $item"
done
