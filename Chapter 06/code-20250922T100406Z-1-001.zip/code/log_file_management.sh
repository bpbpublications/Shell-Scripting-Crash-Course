#!/bin/bash

LOG_DIR="/var/log"

rotate_logs() {
    local file="$LOG_DIR/app.log"
    echo "Rotating logs for $file"
    mv "$file" "$file.bak"
}

rotate_logs
echo "Log directory is still: $LOG_DIR"
