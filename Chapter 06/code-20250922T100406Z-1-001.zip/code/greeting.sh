#!/bin/bash  

greet_user() {
    echo "Hello, $1!"
    echo "Welcome to $2."
}  

# Calling the function with two arguments
greet_user "John" "Linux Scripting"
