#!/bin/bash  

backup_files() {
    src=$1
    dest=$2
    echo "Backing up files from $src to $dest"
    cp -r "$src" "$dest"
    echo "Backup completed!"
}  

# Call function with arguments
backup_files "/home/john/project" "/home/john/backup"  # While trying, use your original paths; this is just an example path.
