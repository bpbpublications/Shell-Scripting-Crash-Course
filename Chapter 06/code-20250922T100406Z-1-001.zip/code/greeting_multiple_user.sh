#!/bin/bash

greet_all() {
    echo "Total users: $#"
    for name in "$@"
    do
        echo "Hello, $name! Welcome to Shell Scripting."
    done
}

# Passing multiple arguments
greet_all Alice Bob Charlie
