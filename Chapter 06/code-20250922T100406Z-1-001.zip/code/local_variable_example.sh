#!/bin/bash

show_message() {
    local message="Hello from inside"   # Local variable
    echo "Inside function: $message"
}

show_message
echo "Outside function: $message"   # Will be empty
