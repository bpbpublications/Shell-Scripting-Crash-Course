#!/bin/bash  

# Function definition
system_health_check() {
    echo "==============================="
    echo "   System Health Check"
    echo "==============================="

    # Check disk usage
    echo -e "\nDisk Usage:"
    df -h | head -n 5     # Shows first 5 lines of disk space in human-readable format

    # Check memory usage
    echo -e "\nMemory Usage:"
    free -h               # Displays memory (RAM) usage in human-readable format

    # Check CPU load
    echo -e "\nCPU Load:"
    uptime                # Shows system uptime and average CPU load
}

# Call the function
system_health_check

# Final message
echo -e "\nAll systems are running fine ✅"
