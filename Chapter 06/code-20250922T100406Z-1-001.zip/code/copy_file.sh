#!/bin/bash

copy_file() {
    src=$1
    dest=$2
    if [ -f "$src" ]; then
        cp "$src" "$dest"
        echo "File $src copied to $dest"
    else
        echo "❌ Source file does not exist."
    fi
}

# Example usage
copy_file myfile.txt /tmp/   # It is just a example, while trying provide actual source and destination paths
