#!/bin/bash

# Script: factorial.sh
# Purpose: Calculate factorial using recursion

factorial() {
    local n=$1
    if [ $n -le 1 ]; then
        echo 1
    else
        local prev=$(factorial $((n - 1)))
        echo $((n * prev))
    fi
}

# Call function with input number
echo "Factorial of 5 is: $(factorial 5)"
