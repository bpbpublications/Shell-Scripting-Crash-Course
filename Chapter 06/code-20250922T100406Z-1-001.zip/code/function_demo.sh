#!/bin/bash

# Function to print a welcome message
welcome() {
    echo "==============================="
    echo "  Welcome to Functions in Bash"
    echo "==============================="
}

# Function to show current date and time
show_time() {
    date "+%A, %d %B %Y %H:%M:%S"
}

# Function to print a goodbye message
goodbye() {
    echo "All tasks are completed. Goodbye!"
}

# Main execution flow
welcome
echo "Current time: $(show_time)"  # Here we call the function inside command substitution to capture its output
goodbye
