#!/bin/bash  

count_args() {
    echo "Number of arguments passed: $#"
    echo "All arguments are: $@"
}  

count_args one two three four
