#!/bin/bash
# Script: return_demo.sh

# Function returning exit status
is_even() {
    if (( $1 % 2 == 0 )); then
        return 0   # even
    else
        return 1   # odd
    fi
}

# Function returning data
get_square() {
    echo $(( $1 * $1 ))
}

# Test exit status return
is_even 4
if [ $? -eq 0 ]; then
    echo "4 is even"
else
    echo "4 is odd"
fi

# Test data return
square=$(get_square 5)
echo "Square of 5 is: $square"
