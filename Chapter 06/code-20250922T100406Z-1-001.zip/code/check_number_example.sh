#!/bin/bash

check_number() {
    if [ $1 -gt 10 ]; then
        return 0   # success
    else
        return 1   # failure
    fi
}

check_number 15
if [ $? -eq 0 ]; then
    echo "Number is greater than 10"
else
    echo "Number is 10 or less"
fi
