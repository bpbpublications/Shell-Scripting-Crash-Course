#!/bin/bash
# Script: service_check.sh
# Purpose: Check if Nginx service is running or not

check_service() {
    systemctl is-active --quiet nginx
    if [ $? -eq 0 ]; then
        echo "running"
        return 0
    else
        echo "stopped"
        return 1
    fi
}

status=$(check_service)

if [ $? -eq 0 ]; then
    echo "✅ Nginx is $status"
else
    echo "❌ Nginx is $status"
fi
