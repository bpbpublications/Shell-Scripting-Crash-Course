#!/bin/bash

fibonacci() {
    local n=$1
    if [ $n -le 0 ]; then
        echo 0
    elif [ $n -eq 1 ]; then
        echo 1
    else
        local a=$(fibonacci $((n - 1)))  # Previous value
        local b=$(fibonacci $((n - 2)))  # Second previous value
        echo $((a + b))                  # Add both
    fi
}

# Print first 6 Fibonacci numbers
for i in {0..5}
do
    echo "Fib($i) = $(fibonacci $i)"
done
