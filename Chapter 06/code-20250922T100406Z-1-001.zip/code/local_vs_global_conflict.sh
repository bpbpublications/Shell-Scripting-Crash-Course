#!/bin/bash

value="Global Value"

test_function() {
    local value="Local Value"
    echo "Inside function: $value"
}

test_function
echo "Outside function: $value"
