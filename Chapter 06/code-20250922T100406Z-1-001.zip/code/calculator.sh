#!/bin/bash
##########################################
# Script: calculator.sh
# Purpose: Perform simple arithmetic using function arguments
# Author: John Doe
##########################################

calculator() {
    num1=$1
    num2=$2
    operator=$3

    case $operator in
        +) echo "Result: $((num1 + num2))" ;;
        -) echo "Result: $((num1 - num2))" ;;
        \*) echo "Result: $((num1 * num2))" ;;
        /) echo "Result: $((num1 / num2))" ;;
        *) echo "Invalid operator. Use + - * /" ;;
    esac
}

# Calling function with arguments
calculator $1 $2 $3

