#!/bin/bash

countdown() {
    local n=$1
    if [ $n -le 0 ]; then
        echo "Time’s up!"   # Base case
    else
        echo "Countdown: $n"
        countdown $((n - 1))   # Recursive call
    fi
}

countdown 5
