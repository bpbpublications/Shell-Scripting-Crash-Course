function function_name {
    commands
}
