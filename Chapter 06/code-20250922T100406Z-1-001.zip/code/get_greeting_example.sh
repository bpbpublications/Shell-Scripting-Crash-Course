#!/bin/bash

get_greeting() {
    echo "Hello, $1!"
}

result=$(get_greeting "Alice")
echo $result
