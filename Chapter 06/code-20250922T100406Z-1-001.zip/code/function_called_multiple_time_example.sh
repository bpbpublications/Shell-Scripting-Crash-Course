#!/bin/bash

say_hello() {
    echo "Hello, World!"
}

# Calling the function multiple times
say_hello
say_hello
say_hello
