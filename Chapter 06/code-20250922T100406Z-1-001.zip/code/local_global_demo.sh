#!/bin/bash

##########################################
# Script: local_global_demo.sh
# Purpose: Demonstrate local vs global variables
# Author: John Doe
##########################################

name="Global John"

print_name() {
    local name="Local Alice"
    echo "Inside function: $name"
}

echo "Before calling function: $name"
print_name
echo "After calling function: $name"
