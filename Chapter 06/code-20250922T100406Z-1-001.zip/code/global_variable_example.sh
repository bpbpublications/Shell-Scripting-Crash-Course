#!/bin/bash

myvar="Hello"   # Global variable

print_message() {
    echo "Inside function: $myvar"
}

print_message
echo "Outside function: $myvar"
