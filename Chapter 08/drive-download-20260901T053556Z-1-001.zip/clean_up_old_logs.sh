#!/bin/bash

# Delete logs older than 30 days
find /var/log -name "*.log" -type f -mtime +30 -exec rm {} \;
echo "Old logs deleted!"