cat > notes.txt
# This is a new file created using cat.
# Press CTRL+D to save and exit.
