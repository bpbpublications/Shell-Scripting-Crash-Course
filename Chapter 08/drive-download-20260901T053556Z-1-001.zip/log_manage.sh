#!/bin/bash

# Archive yesterday’s log
mv app.log app_$(date +%F).log

# Create a fresh empty log
touch app.log

# Remove logs older than 7 days
find . -name "app_*.log" -type f -mtime +7 -exec rm {} \;

echo "Log rotation complete!"
