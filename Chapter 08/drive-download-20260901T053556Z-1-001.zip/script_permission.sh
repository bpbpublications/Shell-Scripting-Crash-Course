#!/bin/bash

# Create a script
echo 'echo "Hello World!"' > hello.sh

# Make it executable
chmod +x hello.sh

# Run the script
./hello.sh
