#!/bin/bash

# Create directories
mkdir -p projects/app/{src,bin,logs}

# Navigate into app directory
cd projects/app

# Print current path
pwd

# Copy logs directory
cp -r logs logs_backup

# Rename src to source
mv src source

# Delete bin directory
rm -r bin

echo "Project directories organized!"
