rm file1.txt
