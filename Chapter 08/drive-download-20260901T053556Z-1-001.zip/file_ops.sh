#!/bin/bash

# Create a file named demo.txt
echo "This is a demo file" > demo.txt

# Rename demo.txt to demo_renamed.txt
mv demo.txt demo_renamed.txt

# Delete the renamed file
rm demo_renamed.txt

# Print completion message
echo "Task completed!"

