#!/bin/bash

# 1. Create a file confidential.txt
touch confidential.txt

# 2. Set permissions so only the owner can read/write
chmod 600 confidential.txt

# 3. Change ownership to root
chown root:root confidential.txt

# 4. Print the final ls -l output of the file
ls -l confidential.txt
