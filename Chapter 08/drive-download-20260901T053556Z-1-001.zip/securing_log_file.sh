#!/bin/bash

logfile="secure.log"

# Create log file
touch $logfile

# Set permissions: owner can read/write, others cannot
chmod 600 $logfile

# Change ownership to root:devops
sudo chown root:devops $logfile

echo "Log file created with restricted access."
