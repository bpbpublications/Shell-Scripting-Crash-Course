#!/bin/bash

# Create the main directory and subdirectories
mkdir -p testdir/data testdir/logs

# Navigate into testdir
cd testdir || exit 1

# Rename logs to logs_archive
mv logs logs_archive

# Copy data into data_copy
cp -r data data_copy

# Delete data_copy
rm -rf data_copy

# Show final directory structure
echo "Final directory structure:"
tree .     # Ensure 'tree' is installed; if not install using `sudo apt-get install tree` # tree command used for representing directory structure
