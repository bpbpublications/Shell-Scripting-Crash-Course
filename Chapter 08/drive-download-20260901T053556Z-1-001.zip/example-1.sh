#!/bin/bash

# Create a file
touch report.txt
echo "Monthly Report Data" > report.txt

# Rename the file
mv report.txt report_july.txt

# Delete the file
rm report_july.txt

echo "File operations completed!"
