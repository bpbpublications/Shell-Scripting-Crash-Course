#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <url>"
    exit 1
fi

URL="$1"

content=$(curl -s "$URL")

if [ -z "$content" ]; then
    echo "Error: Failed to fetch content from URL."
    exit 1
fi

title=$(echo "$content" | grep -i "<title>" | head -1 | sed -e 's/.*<title>//I' -e 's/<\/title>.*//I')
links=$(echo "$content" | grep -o 'href="[^"]*"' | sed 's/href="//;s/"//')

echo "Web Scraping Result"
echo "-------------------"
echo "Page Title: $title"
echo
echo "Extracted Links:"
echo "$links"
