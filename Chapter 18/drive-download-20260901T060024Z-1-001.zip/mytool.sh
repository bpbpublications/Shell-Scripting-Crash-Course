#!/bin/bash
set -euo pipefail

show_info() {
    echo "User       : $(whoami)"
    echo "Hostname   : $(hostname)"
    echo "OS         : $(uname -o)"
}

show_date() {
    date
}

show_uptime() {
    uptime -p
}

show_help() {
    echo "Usage: $0 <command>"
    echo
    echo "Available commands:"
    echo "  info     Show system information"
    echo "  date     Show current date and time"
    echo "  uptime   Show system uptime"
    echo "  help     Display this help message"
}

command="${1:-help}"

case "$command" in
    info)
        show_info
        ;;
    date)
        show_date
        ;;
    uptime)
        show_uptime
        ;;
    help|-h|--help)
        show_help
        ;;
    *)
        echo "Error: Unknown command '$command'"
        echo
        show_help
        exit 1
        ;;
esac
