#!/bin/bash
set -euo pipefail

if [ $# -ne 2 ]; then
    echo "Usage: $0 <directory> <base_name>"
    exit 1
fi

TARGET_DIR="$1"
BASE_NAME="$2"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: Directory does not exist."
    exit 1
fi

# Find the highest existing number
max=0
for file in "$TARGET_DIR"/${BASE_NAME}_*; do
    [ -e "$file" ] || continue
    num=$(basename "$file" | sed -n "s/^${BASE_NAME}_\([0-9]\+\).*/\1/p")
    [[ "$num" =~ ^[0-9]+$ ]] && (( num > max )) && max=$num
done

count=$((max + 1))

# Rename only unprocessed files
for file in "$TARGET_DIR"/*; do
    [ -f "$file" ] || continue

    filename="$(basename "$file")"

    # Skip already renamed files
    [[ "$filename" == ${BASE_NAME}_* ]] && continue

    extension="${filename##*.}"
    new_name="${BASE_NAME}_${count}.${extension}"
    new_path="$TARGET_DIR/$new_name"

    mv "$file" "$new_path"
    echo "Renamed: $filename → $new_name"
    ((count++))
done
