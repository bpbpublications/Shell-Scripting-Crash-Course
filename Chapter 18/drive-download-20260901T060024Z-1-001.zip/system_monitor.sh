#!/bin/bash
set -euo pipefail

echo "System Monitoring Report"
echo "------------------------"

cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
mem_info=$(free -m | awk 'NR==2{printf "Used: %sMB / Total: %sMB (%.2f%%)", $3, $2, $3*100/$2}')
disk_usage=$(df -h | awk '$NF=="/"{printf "%s used of %s (%s)", $3, $2, $5}')

echo "CPU Usage    : $cpu_usage%"
echo "Memory Usage : $mem_info"
echo "Disk Usage   : $disk_usage"
