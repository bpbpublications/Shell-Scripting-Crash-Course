#!/bin/bash
set -euo pipefail

if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_directory> <backup_directory>"
    exit 1
fi

SOURCE_DIR="$1"
BACKUP_DIR="$2"

if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Source directory does not exist."
    exit 1
fi

mkdir -p "$BACKUP_DIR"

timestamp=$(date +"%Y%m%d_%H%M%S")
backup_name="backup_$(basename "$SOURCE_DIR")_$timestamp.tar.gz"
backup_path="$BACKUP_DIR/$backup_name"

tar -czf "$backup_path" -C "$(dirname "$SOURCE_DIR")" "$(basename "$SOURCE_DIR")"

echo "Backup completed successfully."
echo "Backup file created at: $backup_path"
