#!/bin/bash

set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <log_file>"
    exit 1
fi

LOG_FILE="$1"

if [ ! -f "$LOG_FILE" ]; then
    echo "Error: Log file does not exist."
    exit 1
fi

if [ ! -r "$LOG_FILE" ]; then
    echo "Error: Log file is not readable."
    exit 1
fi

error_count=$(grep -c "ERROR" "$LOG_FILE" || true)
warn_count=$(grep -c "WARN" "$LOG_FILE" || true)
info_count=$(grep -c "INFO" "$LOG_FILE" || true)

echo "Log Analysis Summary"
echo "--------------------"
echo "ERROR messages : $error_count"
echo "WARN messages  : $warn_count"
echo "INFO messages  : $info_count"

echo
echo "Top 5 Frequent Log Entries:"
grep -E "ERROR|WARN|INFO" "$LOG_FILE" \
    | awk '{ $1=$2=""; print }' \
    | sort \
    | uniq -c \
    | sort -nr \
    | head -5
