#!/bin/bash

SOURCE="/home/ubuntu/data"
DEST_DIR="/home/ubuntu/backup"
DEST="$DEST_DIR/data_$(date +%F).tar.gz"

mkdir -p "$DEST_DIR"

echo "Backing up $SOURCE ..."
if tar -czf "$DEST" "$SOURCE"; then
  echo "Backup completed: $DEST"
else
  echo "Backup failed!" >&2
  exit 1
fi
