#!/bin/bash

echo "===== Daily Health Check: $(date) ====="
echo

echo "Hostname:"
hostname
echo

echo "Uptime:"
uptime
echo

echo "Disk Usage:"
df -h
echo

echo "Memory Usage:"
free -h
echo "========================================"
