#!/bin/bash

# one_time_backup.sh
# Compress /home/user/data into /tmp/data_backup.tar.gz
# and log the date and time of the backup.

BACKUP_SOURCE="/home/user/data"
BACKUP_TARGET="/tmp/data_backup.tar.gz"
LOG_FILE="/home/user/backup.log"

# Create the backup
tar -czf "$BACKUP_TARGET" "$BACKUP_SOURCE"

# Log the date and time
echo "Backup created at $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"


# schedule the script to run once at a specific time using 'at' command:

    # echo "/home/user/one_time_backup.sh" | at now + 10 minutes
