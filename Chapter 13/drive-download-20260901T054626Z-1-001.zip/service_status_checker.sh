#!/bin/bash

SERVICE="nginx"
TIMESTAMP=$(date)

if systemctl is-active --quiet "$SERVICE"; then
  echo "[$TIMESTAMP] $SERVICE is running."
else
  echo "[$TIMESTAMP] $SERVICE is DOWN! Restarting..."
  sudo systemctl restart "$SERVICE"
fi