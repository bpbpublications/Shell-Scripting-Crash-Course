#!/bin/bash

LOG_DIR="/var/log/myapp"
DAYS=7
ARCHIVE="/tmp/log_archive.tar.gz"

echo "Archiving logs older than $DAYS days..."
find "$LOG_DIR" -type f -mtime +$DAYS -print0 | tar -czf "$ARCHIVE" --null -T -
echo "Archived to: $ARCHIVE"

echo "Deleting old logs..."
find "$LOG_DIR" -type f -mtime +$DAYS -delete

echo "Log cleanup completed."
