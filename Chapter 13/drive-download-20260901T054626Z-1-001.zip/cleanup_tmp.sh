#!/bin/bash

LOGFILE="/var/log/tmp_cleanup.log"
COUNT=0
NOW=$(date "+%Y-%m-%d %H:%M:%S")

# Ensure log file exists
sudo touch "$LOGFILE"
sudo chmod 644 "$LOGFILE"

# Find and delete files older than 3 days
while IFS= read -r file; do
    echo "Deleted: $file" | sudo tee -a "$LOGFILE" > /dev/null
    sudo rm -f "$file"
    COUNT=$((COUNT + 1))
done < <(find /tmp -type f -mtime +3)

# Summary
echo "Total files deleted: $COUNT"
echo "Cleanup completed at: $NOW"
