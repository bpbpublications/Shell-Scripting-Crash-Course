#!/bin/bash
# ------------------------------------------------------------
# autosys.sh - Simple automated system maintenance script
#
# Tasks:
#   - Clean old files in /tmp
#   - Back up /var/log into a dated tar.gz archive
#   - Generate a system health report
#   - Log all output with timestamps to /var/log/autosys_YYYY-MM-DD.log
#   - Optionally send the log via email
#
# Intended to be run as root (manually or via cron).
# ------------------------------------------------------------

set -euo pipefail

# ---- Configurable settings ----
DATE="$(date +%F)"
LOGFILE="/var/log/autosys_${DATE}.log"
TMP_DIR="/tmp"
LOG_DIR="/var/log"
BACKUP_DIR="/var/backups"

OLD_TMP_DAYS=3          # "Old" temp files = older than 3 days
OLD_LOG_DAYS=7          # "Old" logs for backup = older than 7 days
ARCHIVE="${BACKUP_DIR}/log_backup_${DATE}.tar.gz"

EMAIL_TO=""             # Set to an email address to enable notifications, e.g. "you@example.com"
EMAIL_SUBJECT="Autosys maintenance report - ${DATE}"

# ---- Require root ----
if [[ "$EUID" -ne 0 ]]; then
    echo "ERROR: This script must be run as root." >&2
    exit 1
fi

# ---- Prepare log and backup directory ----
mkdir -p "$BACKUP_DIR"
touch "$LOGFILE"
chmod 640 "$LOGFILE"

# ---- Logging helper ----
log() {
    echo "[$(date '+%F %T')] $*" | tee -a "$LOGFILE"
}

# ---- Clean /tmp old files ----
cleanup_tmp() {
    log "Starting cleanup of temporary files older than ${OLD_TMP_DAYS} days in ${TMP_DIR}..."

    # List and delete in one go; details appended to log file
    find "$TMP_DIR" -type f -mtime +"$OLD_TMP_DAYS" -print -delete >>"$LOGFILE" 2>&1

    log "Temporary files cleanup completed."
}

# ---- Back up /var/log ----
backup_logs() {
    log "Starting backup of log files in ${LOG_DIR} older than ${OLD_LOG_DAYS} days..."
    log "Creating archive: ${ARCHIVE}"

    # Create compressed archive of old log files
    # Only files older than OLD_LOG_DAYS are included
    if find "$LOG_DIR" -type f -mtime +"$OLD_LOG_DAYS" -print0 | \
        tar -czf "$ARCHIVE" --null -T - >>"$LOGFILE" 2>&1; then
        log "Log backup completed successfully. Archive stored at ${ARCHIVE}"
    else
        log "WARNING: Log backup encountered an error."
    fi
}

# ---- System health report ----
health_report() {
    log "Generating system health report..."

    {
        echo ""
        echo "===== SYSTEM HEALTH REPORT ====="
        echo "Date: $(date)"
        echo ""
        echo "Uptime:"
        uptime
        echo ""
        echo "Disk Usage (df -h):"
        df -h
        echo ""
        echo "Memory Usage (free -h):"
        free -h
        echo ""
        echo "Top 5 CPU Processes:"
        ps -eo pid,comm,%cpu,%mem --sort=-%cpu | head -6
        echo ""
        echo "Top 5 Memory Processes:"
        ps -eo pid,comm,%mem,%cpu --sort=-%mem | head -6
        echo ""
        echo "Open TCP Listening Ports:"
        ss -tulpn 2>/dev/null | head -20 || netstat -tulpn 2>/dev/null | head -20 || echo "ss/netstat not available."
        echo "===== END OF HEALTH REPORT ====="
        echo ""
    } >>"$LOGFILE" 2>&1

    log "System health report appended to log."
}

# ---- Optional email notification ----
send_email() {
    # If EMAIL_TO is empty, skip
    if [[ -z "${EMAIL_TO}" ]]; then
        log "Email notification disabled (no EMAIL_TO configured)."
        return
    fi

    # Check if 'mail' command exists
    if command -v mail >/dev/null 2>&1; then
        log "Sending email notification to ${EMAIL_TO}..."
        if mail -s "$EMAIL_SUBJECT" "$EMAIL_TO" < "$LOGFILE"; then
            log "Email notification sent successfully to ${EMAIL_TO}."
        else
            log "WARNING: Failed to send email notification to ${EMAIL_TO}."
        fi
    else
        log "mail command not found; skipping email notification."
    fi
}

# ---- Main orchestration ----
main() {
    log "Autosys maintenance run started."

    cleanup_tmp
    backup_logs
    health_report
    send_email

    log "Autosys maintenance run completed."
}

main
