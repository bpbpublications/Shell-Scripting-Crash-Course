#!/bin/bash

REPORT="/tmp/health_report_$(date +%F).txt"

{
  echo "===== SYSTEM HEALTH REPORT ====="
  echo "Date: $(date)"
  echo ""
  echo "Uptime:"
  uptime
  echo ""
  echo "Disk Usage:"
  df -h
  echo ""
  echo "Memory Usage:"
  free -h
  echo ""
  echo "Top 5 Memory Consuming Processes:"
  ps -eo pid,comm,%mem --sort=-%mem | head -6
} > "$REPORT"

echo "Report saved to $REPORT"
